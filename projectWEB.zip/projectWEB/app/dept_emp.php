<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class dept_emp extends Model
{
    public $table='dept_emp';
    public $timestamp =false;

}
