<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class salaries extends Model
{
    public $table='salaries';
        public $primaryKey='emp_no';

}
