<div class="container">
   <div class="row">
   
		<?php $__currentLoopData = $show; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $var): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4"> 
     
      <div class="block-deal">
        <div >
             </div>
              <div class="block-desc">
                <p align="center"><?php echo e($var->first_name); ?></p>
                <p align="center"><?php echo e($var->last_name); ?></p>
                <p align="center"><?php echo e($var->gender); ?></p>
              </div>
      </div>  
           </a>
       </div>
	  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  		<?php echo e($show->links()); ?>

  </div>
</div>